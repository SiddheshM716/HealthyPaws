//
//  SQLiteDatabase.swift
//  HealthyPaws
//
//  Created by Siddhesh M on 16/02/25.
//
import SwiftUI
import SQLite3

// MARK: - SQLite Helper Class
@MainActor

class SQLiteDatabase {
    static let shared = SQLiteDatabase() // Singleton instance
    var db: OpaquePointer?

    private init() {
        let fileURL = try! FileManager.default
            .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("petInfoDatabase.db")

        print("Database file path: \(fileURL.path)")

        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Database opened successfully!")
        }

        createTables() // Call the new method to create all tables
    }

    private func createTables() {
        // Create the pets table
        let createPetsTableQuery = """
        CREATE TABLE IF NOT EXISTS pets (
            petId INTEGER PRIMARY KEY AUTOINCREMENT,
            petType TEXT,
            petBreed TEXT,
            petWeight TEXT,
            petDOB TEXT,
            petGender TEXT,
            pname TEXT  
        );
        """

        if sqlite3_exec(db, createPetsTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creating pets table: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Pets table created successfully.")
        }

        // Create the feeding records table
        let createFeedingTableQuery = """
        CREATE TABLE IF NOT EXISTS feedingRecords (
            recordId INTEGER PRIMARY KEY AUTOINCREMENT,
            petId INTEGER,
            timestamp TEXT,
            FOREIGN KEY (petId) REFERENCES pets(petId)
        );
        """

        if sqlite3_exec(db, createFeedingTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creating feedingRecords table: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("FeedingRecords table created successfully.")
        }
    }
    func savePetInfo(petType: String, breed: String, weight: String, dob: String, gender: String, pname: String) {
        print("Inserting: petType=\(petType), breed=\(breed), weight=\(weight), dob=\(dob), gender=\(gender), pname=\(pname)")

        let insertQuery = "INSERT INTO pets (petType, petBreed, petWeight, petDOB, petGender, pname) VALUES (?, ?, ?, ?, ?, ?);"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing insert query: \(String(cString: sqlite3_errmsg(db)))")
            return
        }

        sqlite3_bind_text(statement, 1, (petType as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 2, (breed as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 3, (weight as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 4, (dob as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 5, (gender as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 6, (pname as NSString).utf8String, -1, nil)  // Bind the pet's name

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error executing insert query: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Pet information saved successfully.")
        }

        sqlite3_finalize(statement)
    }

    // Function to add a feeding record
    func addFeedingRecord(petId: Int) {
        let timestamp = ISO8601DateFormatter().string(from: Date()) // Get current timestamp
        let insertQuery = "INSERT INTO feedingRecords (petId, timestamp) VALUES (?, ?);"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing insert query: \(String(cString: sqlite3_errmsg(db)))")
            return
        }

        sqlite3_bind_int(statement, 1, Int32(petId))
        sqlite3_bind_text(statement, 2, (timestamp as NSString).utf8String, -1, nil)

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error executing insert query: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Feeding record saved successfully.")
        }

        sqlite3_finalize(statement)
    }
    func fetchAllPets() -> [Pet]? {
        let query = "SELECT petId, petType, petBreed, petWeight, petDOB, petGender, pname FROM pets;"
        var statement: OpaquePointer?
        var pets: [Pet] = []

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing fetch query: \(String(cString: sqlite3_errmsg(db)))")
            return nil
        }

        while sqlite3_step(statement) == SQLITE_ROW {
            let petId = Int(sqlite3_column_int(statement, 0))
            let petType = String(cString: sqlite3_column_text(statement, 1))
            let petBreed = String(cString: sqlite3_column_text(statement, 2))
            let petWeight = String(cString: sqlite3_column_text(statement, 3))
            let petDOB = String(cString: sqlite3_column_text(statement, 4))
            let petGender = String(cString: sqlite3_column_text(statement, 5))
            let pname = String(cString: sqlite3_column_text(statement, 6))

            let pet = Pet(id: petId, petType: petType, petBreed: petBreed, petWeight: petWeight, petDOB: petDOB, petGender: petGender, pname: pname)
            pets.append(pet)
        }

        sqlite3_finalize(statement)
        return pets.isEmpty ? nil : pets
    }
    func getLastInsertedPetId() -> Int? {
            let query = "SELECT last_insert_rowid()"
            var statement: OpaquePointer?

            if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
                print("Error preparing last_insert_rowid query")
                return nil
            }

            if sqlite3_step(statement) == SQLITE_ROW {
                let petId = sqlite3_column_int(statement, 0)
                sqlite3_finalize(statement)
                return Int(petId)
            }

            sqlite3_finalize(statement)
            return nil
        }

    func fetchPetDetails(petId: Int) -> Pet? {
        let query = "SELECT petType, petBreed, petWeight, petDOB, petGender, pname FROM pets WHERE petId = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing fetch query: \(String(cString: sqlite3_errmsg(db)))")
            return nil
        }

        sqlite3_bind_int(statement, 1, Int32(petId))

        if sqlite3_step(statement) == SQLITE_ROW {
            let petType = String(cString: sqlite3_column_text(statement, 0))
            let petBreed = String(cString: sqlite3_column_text(statement, 1))
            let petWeight = String(cString: sqlite3_column_text(statement, 2))
            let petDOB = String(cString: sqlite3_column_text(statement, 3))
            let petGender = String(cString: sqlite3_column_text(statement, 4))
            let pname = String(cString: sqlite3_column_text(statement, 5))  // Fetch the pet's name

            sqlite3_finalize(statement)
            return Pet(id: petId, petType: petType, petBreed: petBreed, petWeight: petWeight, petDOB: petDOB, petGender: petGender, pname: pname)
        }

        sqlite3_finalize(statement)
        return nil
    }
    func fetchMostRecentFeedingRecord(petId: Int) -> String? {
        let query = "SELECT timestamp FROM feedingRecords WHERE petId = ? ORDER BY timestamp DESC LIMIT 1;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing fetch query: \(String(cString: sqlite3_errmsg(db)))")
            return nil
        }

        sqlite3_bind_int(statement, 1, Int32(petId))

        if sqlite3_step(statement) == SQLITE_ROW {
            if let timestamp = sqlite3_column_text(statement, 0) {
                let timestampString = String(cString: timestamp)
                sqlite3_finalize(statement)
                return timestampString
            }
        }

        sqlite3_finalize(statement)
        return nil
    }
    
    // Function to update pet details
    func updatePetInfo(petId: Int, petType: String, breed: String, weight: String, dob: String, gender: String, pname: String) {
        let updateQuery = "UPDATE pets SET petType = ?, petBreed = ?, petWeight = ?, petDOB = ?, petGender = ?, pname = ? WHERE petId = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, updateQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing update query: \(String(cString: sqlite3_errmsg(db)))")
            return
        }

        sqlite3_bind_text(statement, 1, (petType as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 2, (breed as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 3, (weight as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 4, (dob as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 5, (gender as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 6, (pname as NSString).utf8String, -1, nil)
        sqlite3_bind_int(statement, 7, Int32(petId))

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error executing update query: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Pet information updated successfully.")
        }

        sqlite3_finalize(statement)
    }

    // Function to delete a pet
    func deletePet(petId: Int) {
        let deleteQuery = "DELETE FROM pets WHERE petId = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, deleteQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing delete query: \(String(cString: sqlite3_errmsg(db)))")
            return
        }

        sqlite3_bind_int(statement, 1, Int32(petId))

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error executing delete query: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Pet deleted successfully.")
        }

        sqlite3_finalize(statement)
    }
    
    // Function to fetch feeding records for a specific pet
    func fetchFeedingRecords(petId: Int) -> [String]? {
        let query = "SELECT timestamp FROM feedingRecords WHERE petId = ?;"
        var statement: OpaquePointer?
        var timestamps: [String] = []

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing fetch query: \(String(cString: sqlite3_errmsg(db)))")
            return nil
        }

        sqlite3_bind_int(statement, 1, Int32(petId))

        while sqlite3_step(statement) == SQLITE_ROW {
            if let timestamp = sqlite3_column_text(statement, 0) {
                timestamps.append(String(cString: timestamp))
            }
        }

        sqlite3_finalize(statement)
        return timestamps.isEmpty ? nil : timestamps
    }
}
