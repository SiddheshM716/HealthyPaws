import SwiftUI

struct ContentView: View {
    @State private var showMainView = false
    @State private var showMenu = false
    @State private var searchText = ""
    @State private var showStatisticsPage: Bool = false
    @State private var pets: [Pet] = []
    @State private var isSearching = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background Pawprints
                VStack {
                    HStack {
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 75, height: 75)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding(.leading, 25)
                            .padding(.top, 60)
                        Spacer()
                    }
                    Spacer()
                }
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 150, height: 150)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding()
                    }
                }
                
                // Main Content
                VStack {
                    HStack {
                        Text("HealthyPaws")
                            .font(.system(size: 35, weight: .bold))
                            .padding(.top, 80)
                            .padding()
                        Spacer()
                    }
                    
                    // Search Bar
                    if isSearching {
                        HStack {
                            TextField("Search for a pet...", text: $searchText)
                                .padding(10)
                                .background(Color(.systemGray6))
                                .cornerRadius(15)
                                .padding(.horizontal)
                            
                            Button(action: {
                                isSearching = false
                                searchText = ""
                            }) {
                                Text("Cancel")
                            }
                            .padding(.trailing)
                        }
                        .transition(.move(edge: .top))
                    }
                    
                    // Display Pet Tiles
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(spacing: 20) {
                            ForEach(filteredPets, id: \.id) { pet in
                                NavigationLink(destination: PetStatisticsView(petId: pet.id)) {
                                    PetTile(pet: pet)
                                }
                            }
                        }
                        .padding()
                    }
                    
                    Spacer()
                    NavigationStack {
                        Text("").padding()
                            .toolbar {
                                ToolbarItemGroup(placement: .bottomBar) {
                                    HStack(alignment: .center, spacing: 90.0){
                                        NavigationLink(destination: PetInfoFormView()) {
                                            VStack{
                                                Label("Add Pet", systemImage: "plus.circle")
                                                Text("Add Pet").font(.system(size: 15))
                                            }
                                        }.padding(.top,20).frame(width: 30.0, height: 30.0)
                                        
                                        Button(action: {
                                            withAnimation {
                                                isSearching.toggle()
                                            }
                                        }) {
                                            VStack {
                                                Image(systemName: "magnifyingglass")
                                                Text("Search").font(.system(size: 15))
                                            }
                                        }.padding(.top,20).frame(width: 30.0, height: 30.0)
                                        
                                        NavigationLink(destination: TipsView()) {
                                            VStack{
                                                Label("Add Pet", systemImage: "lightbulb")
                                                Text("Tips").font(.system(size: 15))
                                            }
                                        }.padding(.top,20).frame(width: 30.0, height: 30.0)
                                    }
                                }
                            }
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Section {
                            NavigationLink(destination: PetInfoFormView()) {
                                Label("Add Pets", systemImage: "plus.circle")
                            }
                            
                            NavigationLink(destination: EditPetsView()) {
                                Label("Edit Pets", systemImage: "pencil.circle")
                            }
                            NavigationLink(destination: EmergencyView()) {
                                Label("Emergency Helplines", systemImage: "hazardsign")
                            }
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundColor(.blue)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .ignoresSafeArea()
            .onAppear {
                fetchPets()
            }
        }
    }
    
    private func fetchPets() {
        if let fetchedPets = SQLiteDatabase.shared.fetchAllPets() {
            pets = fetchedPets
        }
    }
    
    var filteredPets: [Pet] {
        if searchText.isEmpty {
            return pets
        } else {
            return pets.filter { $0.pname.localizedCaseInsensitiveContains(searchText) }
        }
    }
}

//
//  TipsView.swift
//  HealthyPaws
//
//  Created by Siddhesh M on 16/02/25.
//

import SwiftUI

struct TipsView: View {
    var body: some View {
        ZStack {
            // Background Pawprints
            VStack {
                HStack {
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 75, height: 75)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding(.leading, 25)
                        .padding(.top, 60)
                    Spacer()
                }
                Spacer()
            }
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding()
                }
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    Text("**Pet Care Tips**")
                        .font(.largeTitle)
                        .padding(.bottom, 10)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Persian**").font(.title2)
                        Text("Feeding: High-protein diet with omega-3 and omega-6 fatty acids.")
                        Text("Avoid: Dairy products, raw fish, onions, garlic.")
                        Text("Vaccination Interval: Every 1-3 years as per vet advice.")
                        Text("Bathing: Once every 4-6 weeks.")
                        Text("Brushing: Daily to prevent matting.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Siamese**").font(.title2)
                        Text("Feeding: Lean meats, high-quality dry and wet food.")
                        Text("Avoid: Chocolate, alcohol, grapes, raw meat.")
                        Text("Vaccination Interval: Every 1-3 years as recommended.")
                        Text("Bathing: Rarely needed, only when dirty.")
                        Text("Brushing: Once or twice a week.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Maine Coon**").font(.title2)
                        Text("Feeding: Protein-rich diet, mix of dry and wet food.")
                        Text("Avoid: Excessive carbs, dairy, onions, garlic.")
                        Text("Vaccination Interval: Annually or as per vet guidance.")
                        Text("Bathing: Once every 6 weeks.")
                        Text("Brushing: 3-4 times a week.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Ragdoll**").font(.title2)
                        Text("Feeding: High-quality kibble, occasional wet food.")
                        Text("Avoid: Raw eggs, caffeine, chocolate.")
                        Text("Vaccination Interval: Every 1-3 years.")
                        Text("Bathing: Every 4-6 weeks.")
                        Text("Brushing: 2-3 times a week.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Golden Retriever**").font(.title2)
                        Text("Feeding: Balanced diet with proteins, carbs, and healthy fats.")
                        Text("Avoid: Chocolate, grapes, onions, bones.")
                        Text("Vaccination Interval: Annually.")
                        Text("Bathing: Once every 6-8 weeks.")
                        Text("Brushing: Daily to reduce shedding.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Bulldog**").font(.title2)
                        Text("Feeding: Lean proteins, limited fats, and carbs.")
                        Text("Avoid: Dairy, spicy food, excess salt.")
                        Text("Vaccination Interval: Every year.")
                        Text("Bathing: Once a month.")
                        Text("Brushing: 2-3 times a week.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Poodle**").font(.title2)
                        Text("Feeding: High-quality dry food, occasional wet food.")
                        Text("Avoid: Raw eggs, onions, garlic.")
                        Text("Vaccination Interval: Annually or as per vet.")
                        Text("Bathing: Every 3-6 weeks.")
                        Text("Brushing: Daily to prevent matting.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("**Beagle**").font(.title2)
                        Text("Feeding: Protein-rich kibble, limited treats.")
                        Text("Avoid: Chocolate, grapes, onions.")
                        Text("Vaccination Interval: Once a year.")
                        Text("Bathing: Every 4-6 weeks.")
                        Text("Brushing: 2-3 times a week.")
                    }
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.gray.opacity(0.15))
                    .cornerRadius(15)
                }
                .padding()
            }
        }
    }
}

struct TipsView_Previews: PreviewProvider {
    static var previews: some View {
        TipsView()
    }
}
