import SwiftUI

struct ContentView: View {
    @State private var showMainView = false
    @State private var showMenu = false
    @State private var searchText = ""
    @State private var petCount = 0
    @State private var showStatisticsPage: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Background Pawprints
                VStack {
                    HStack {
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 75, height: 75)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding(.leading, 25)
                            .padding(.top, 60)
                        Spacer()
                    }
                    Spacer()
                }
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 150, height: 150)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding()
                    }
                }
                
                // Main Content
                VStack {
                    HStack {
                        Text("HealthyPaws")
                            .font(.system(size: 35, weight: .bold))
                            .padding(.top, 80)
                            .padding()
                        Spacer()
                    }
                    Spacer()
                    
                    if petCount == 0 {
                        NavigationLink(destination: MainView()) {
                            Label("Add Pets", systemImage: "plus.circle").font(.system(size: 20))
                        }
                        
                        Spacer()
                    }
                }
                
                // Menu Overlay
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Section {
                            NavigationLink(destination: MainView()) {
                                Label("Add Pets", systemImage: "plus.circle.fill")
                            }
                            Button(action: { print("Edit Pets") }) {
                                Label("Edit Pets ", systemImage: "pencil.circle.fill")
                            }
                            Button(action: { print("Connect to Server") }) {
                                Label("Feeding Tips", systemImage: "info.circle.fill")
                            }
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                            .foregroundColor(.blue)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .ignoresSafeArea()
        }
    }
}
