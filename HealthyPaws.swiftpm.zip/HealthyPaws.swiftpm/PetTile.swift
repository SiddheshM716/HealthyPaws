//
//  PetTile.swift
//  HealthyPaws
//
//  Created by Siddhesh M on 16/02/25.
//


// Pet Tile View
import SwiftUI
import Foundation

struct PetTile: View {
    var pet: Pet
    @State private var petImage: UIImage? = nil
    @StateObject private var timerManager = TimerManager() // Use TimerManager
    @State private var isTimerEnded: Bool = false
    @State private var foodRequirements: PetFoodRequirements?
    @State private var feedingRecords: [String] = []
    

    var body: some View {
        HStack{
            VStack(alignment: .leading) {
            HStack {
                // Display the pet's image or a placeholder
                if let petImage = petImage {
                    Image(uiImage: petImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 120, height: 120).clipShape(Circle())
                } else {
                    Image(systemName: "photo.circle")
                        .resizable()
                        .scaledToFit().clipShape(Circle())
                        .frame(width: 120, height: 120)
                        .foregroundColor(.gray)
                    
                }
                
                // Pet details
                VStack(alignment: .leading, spacing: 5) {
                    Spacer()
                    Text(pet.pname)
                        .font(.title2)
                        .fontWeight(.bold)
                        .lineLimit(1)
                    
                    Text(pet.petBreed)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Text("\(pet.petWeight) kg")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Button(action: logFeeding) {
                        Text("Feed")
                            .padding(.horizontal, 13).padding(.vertical,9)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    // Display last feeding time
                    
                    
                    
                }
                .padding(.leading, 10)
                Spacer()
                ZStack {
                    Circle()
                        .stroke(lineWidth: 10)
                        .opacity(0.3)
                        .foregroundColor(Color.gray)
                    
                    Circle()
                        .trim(from: 0.0, to: CGFloat(1 - (timerManager.timeRemaining / calculateFeedingInterval(for: pet))))
                        .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                        .foregroundColor(isTimerEnded ? Color.red : Color.blue) // Change color based on timer state
                        .rotationEffect(Angle(degrees: 270.0))
                        .animation(.linear, value: timerManager.timeRemaining)
                    
                    // Display pet emoji based on timer progress
                    if let petEmoji = petEmoji(for: pet, progress: timerManager.timeRemaining / calculateFeedingInterval(for: pet)) {
                        petEmoji
                            .resizable()
                            .scaledToFit()
                            .frame(width: 85, height: 85)
                    }
                }
                .frame(width: 110.0, height: 110.0)
                
                
                
                
            }
            .padding()
            .frame(width: 400, height: 140)
            HStack{
                if let lastFeedingTime = fetchLastFeedingTime() {
                    Text("Last Fed: \(lastFeedingTime)")
                        .font(.subheadline)
                        .foregroundColor(.gray).padding()
                } else {
                    Text("Last Fed: N/A")
                        .font(.subheadline)
                        .foregroundColor(.gray).padding()
                }
                Spacer()
                if let nextFeedingTime = timerManager.nextFeedingTime {
                    Text("Next Meal: \(nextFeedingTime, style: .timer)")
                        .font(.caption)
                        .lineLimit(1)
                        .frame(width: 125).padding()
                }
                
            }.padding(.top,-15)
        }
            
            
        }
        .background(Color.gray.opacity(0.1))
        .cornerRadius(15)
        .onAppear {
            loadPetImage()
            foodRequirements = calculateFoodRequirements(for: pet) 
            startFeedingTimer()
        }
        .onDisappear {
            timerManager.stopTimer()
        }
        
    }
    
    // Helper function to fetch last feeding time
    
    private func logFeeding() {
        guard let foodRequirements = foodRequirements else {
            print("Error: foodRequirements is nil")
            return
        }
        
        SQLiteDatabase.shared.addFeedingRecord(petId: pet.id)
        fetchFeedingRecords()
        
        // Restart the timer only after logging a feeding
        timerManager.startTimer(feedingInterval: foodRequirements.feedingInterval, lastFeedingTime: Date())
    }
    
    private func fetchFeedingRecords() {
        if let records = SQLiteDatabase.shared.fetchFeedingRecords(petId: pet.id) {
            feedingRecords = records
        }
    }
    

    
    private func fetchLastFeedingTime() -> String? {
        if let mostRecentFeedingTimestamp = SQLiteDatabase.shared.fetchMostRecentFeedingRecord(petId: pet.id),
           let lastFeedingTime = ISO8601DateFormatter().date(from: mostRecentFeedingTimestamp) {
            return DateFormatter.localizedString(from: lastFeedingTime, dateStyle: .short, timeStyle: .short)
        }
        return nil
    }
    
    // Helper function to get pet emoji based on progress
    private func petEmoji(for pet: Pet, progress: Double) -> Image? {
        switch pet.petType {
        case "Cat":
            if progress > 0.5 {
                return Image("smilingcat")
            } else if progress > 0 {
                return Image("neutralcat")
            } else {
                return Image("sadcat")
            }
        case "Dog":
            if progress > 0.5 {
                return Image("smilingdog")
            } else if progress > 0 {
                return Image("neutraldog")
            } else {
                return Image("saddog")
            }
        default:
            return nil
        }
    }
    
    // Start the feeding timer using TimerManager
    private func startFeedingTimer() {
        let feedingInterval = calculateFeedingInterval(for: pet)

        if let mostRecentFeedingTimestamp = SQLiteDatabase.shared.fetchMostRecentFeedingRecord(petId: pet.id) {
            let dateFormatter = ISO8601DateFormatter()
            if let lastFeedingTime = dateFormatter.date(from: mostRecentFeedingTimestamp) {
                timerManager.startTimer(feedingInterval: feedingInterval, lastFeedingTime: lastFeedingTime)
            }
        } else {
            timerManager.startTimer(feedingInterval: feedingInterval, lastFeedingTime: nil)
        }
    }

    // Calculate feeding interval based on pet type, age, and weight
    private func calculateFeedingInterval(for pet: Pet) -> TimeInterval {
        let weight = Double(pet.petWeight) ?? 0.0
        let age = pet.age ?? 0

        if pet.petType == "Dog" {
            if age < 1 {
                return 4 * 3600 // Puppies: every 4 hours
            } else if weight < 10 {
                return 6 * 3600 // Small adult dogs: every 6 hours
            } else if weight < 25 {
                return 8 * 3600 // Medium adult dogs: every 8 hours
            } else {
                return 10 * 3600 // Large adult dogs: every 10 hours
            }
        } else if pet.petType == "Cat" {
            if age < 1 {
                return 4 * 3600 // Kittens: every 4 hours
            } else if weight < 4 {
                return 6 * 3600 // Small adult cats: every 6 hours
            } else {
                return 8 * 3600 // Larger adult cats: every 8 hours
            }
        }

        return 3600 // Default to 1 hour if pet type is unknown
    }

    // Load pet image from JSON file
    func loadPetImage() {
        petImage = loadImageFromJSON(petId: pet.id)
    }

    // Helper function to load image from JSON
    func loadImageFromJSON(petId: Int) -> UIImage? {
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("petImage_\(petId).json")
        
        do {
            let jsonData = try Data(contentsOf: fileURL)
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let imageBase64String = json["image"] as? String,
               let imageData = Data(base64Encoded: imageBase64String) {
                return UIImage(data: imageData)
            }
        } catch {
            print("Error loading image from JSON: \(error)")
        }
        return nil
    }
}
