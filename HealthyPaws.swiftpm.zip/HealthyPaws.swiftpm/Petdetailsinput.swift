import SwiftUI
import SQLite3
import PhotosUI
import Charts
import UserNotifications
// MARK: - Main View



// MARK: - Pet Model
struct Pet:Identifiable {
    var id: Int
    var petType: String
    var petBreed: String
    var petWeight: String
    var petDOB: String
    var petGender: String
    var pname: String  // Add this line to include the pet's name

    // Computed property to calculate age from DOB
    var age: Int? {
        let dateFormatter = ISO8601DateFormatter()
        guard let dobDate = dateFormatter.date(from: petDOB) else { return nil }
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: dobDate, to: Date())
        return ageComponents.year
    }
}



// MARK: - Pet Statistics View


struct PetStatisticsView: View {
    var petId: Int
    @State private var pet: Pet?
    @State private var isLoading = true
    @State private var feedingRecords: [Date] = [] // Store feeding records as Date objects
    @State private var petImage: UIImage? = nil
    @State private var foodRequirements: PetFoodRequirements?
    @State private var isTimerEnded: Bool = false
    @StateObject private var timerManager = TimerManager()
    
    let db = SQLiteDatabase.shared
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                if isLoading {
                    Text("Loading pet details...")
                        .font(.system(size: 35))
                        .foregroundColor(.gray)
                } else if let pet = pet {
                    ZStack {
                        // Background Pawprints
                        VStack {
                            HStack {
                                Image(systemName: "pawprint.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .rotationEffect(.degrees(-25))
                                    .frame(width: 75, height: 75)
                                    .foregroundColor(.gray.opacity(0.2))
                                    .padding(.leading, 25)
                                    .padding(.top, 60)
                                Spacer()
                            }
                            Spacer()
                        }
                        VStack {
                            Spacer()
                            HStack {
                                Spacer()
                                Image(systemName: "pawprint.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .rotationEffect(.degrees(-25))
                                    .frame(width: 150, height: 150)
                                    .foregroundColor(.gray.opacity(0.2))
                                    .padding()
                            }
                        }
                        
                        VStack{
                            HStack {
                                Text("\(pet.pname)")
                                    .font(.system(size: 45))
                                    .fontWeight(.bold)
                                Spacer()
                            }
                            
                            HStack{
                                Spacer()
                                if let petImage = petImage {
                                    Image(uiImage: petImage)
                                        .resizable()
                                        .scaledToFit()
                                        .clipShape(Circle())
                                        .frame(height: 200)
                                } else {
                                    Image(systemName: "photo.circle")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 200, height: 200)
                                        .foregroundColor(.gray)
                                        .clipShape(Circle())
                                }
                                Spacer()
                            }.padding()
                            HStack{
                                VStack(alignment: .leading, spacing: 6.0){
                                    HStack{
                                        Text("**Weight:** \(pet.petWeight) kg")
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                    HStack{
                                        Text("**Breed:** \(pet.petBreed)")
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                    // Format Date of Birth
                                    if let dob = formatDate(pet.petDOB) {
                                        Text("**Date of Birth:**\(dob)")
                                            .fixedSize(horizontal: false, vertical: true)
                                        
                                    }
                                    
                                    // Display Age with Months
                                    if let age = calculateAgeWithMonths(pet.petDOB) {
                                        HStack{
                                            Text("**Age:** \(age)").fixedSize(horizontal: false, vertical: true)
                                        }
                                    }
                                    HStack{
                                        Text("**Gender:** \(pet.petGender)")
                                    }
                                    if let foodRequirements = foodRequirements {
                                        HStack{
                                            Text("**Food Amount:** \(String( foodRequirements.foodAmount*1000)) grams").fixedSize(horizontal: false, vertical: true)
                                        }
                                        VStack(alignment: .leading){
                                            Text("**Food Type:** \(foodRequirements.foodType)").fixedSize(horizontal: false, vertical: true)
                                        }
                                        VStack(alignment: .leading){
                                            Text("**Feeding Interval:** \(Int(foodRequirements.feedingInterval / 3600)) hours").fixedSize(horizontal: false, vertical: true)
                                        }
                                    }
                                }.padding().background(Color.gray.opacity(0.1)).cornerRadius(15)
                                
                                VStack(alignment: .center, spacing: 5.0){Spacer()
                                    // Visual Timer
                                    VStack(alignment: .center) {
                                        ZStack {
                                                            Circle()
                                                                .stroke(lineWidth: 10)
                                                                .opacity(0.3)
                                                                .foregroundColor(Color.gray)
                                                            
                                                            Circle()
                                                                .trim(from: 0.0, to: CGFloat(1 - (timerManager.timeRemaining / calculateFeedingInterval(for: pet))))
                                                                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                                                                .foregroundColor(isTimerEnded ? Color.red : Color.blue) // Change color based on timer state
                                                                .rotationEffect(Angle(degrees: 270.0))
                                                                .animation(.linear, value: timerManager.timeRemaining)
                                                            
                                                            // Display pet emoji based on timer progress
                                                            if let petEmoji = petEmoji(for: pet, progress: timerManager.timeRemaining / calculateFeedingInterval(for: pet)) {
                                                                petEmoji
                                                                    .resizable()
                                                                    .scaledToFit()
                                                                    .frame(width: 85, height: 85)
                                                            }
                                                        }
                                                        .frame(width: 120.0, height: 120.0)
                                    }
                                    
                                    if let nextFeedingTime = timerManager.nextFeedingTime {
                                        Text("Next Meal: \(nextFeedingTime, style: .timer)")
                                            .font(.subheadline)
                                            .fontWeight(.medium)
                                            .foregroundColor(Color.blue)
                                            .lineLimit(1).frame(width:150).padding(.vertical,10)
                                        
                                            
                                    }
                                    
                                    Button(action: logFeeding) {
                                        Text("Feed \(pet.pname)")
                                            .padding()
                                            .background(Color.blue)
                                            .foregroundColor(.white)
                                            .cornerRadius(15)
                                    }
                                    Spacer()
                                }.padding().background(Color.gray.opacity(0.1)).cornerRadius(15)
                            }
                            // Graphical Feeding History (Dot Graph for Last 24 Hours)
                            // Inside PetStatisticsView's body
                            if !feedingRecords.isEmpty {
                                FeedingHistoryView(feedingRecords: feedingRecords)
                            } else {
                                Text("No feeding records found.")
                                    .foregroundColor(.gray)
                                    .padding()
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(15)
                            }
                            
                        }
                    }.ignoresSafeArea()
                } else {
                    Text("No pet details found.")
                        .foregroundColor(.red)
                }
            }
            .padding()
            .onAppear {
                fetchPetDetails()
                fetchFeedingRecords()
                loadPetImage()
            }
            .onDisappear {
                timerManager.stopTimer()
            }
        }
    }
    
    private func fetchPetDetails() {
        print("Fetching pet details for petId: \(petId)")
        
        if let petDetails = db.fetchPetDetails(petId: petId) {
            pet = petDetails
            foodRequirements = calculateFoodRequirements(for: petDetails)
            
            // Start the timer using TimerManager
            if let mostRecentFeedingTimestamp = db.fetchMostRecentFeedingRecord(petId: petId) {
                let dateFormatter = ISO8601DateFormatter()
                if let lastFeedingTime = dateFormatter.date(from: mostRecentFeedingTimestamp) {
                    timerManager.startTimer(feedingInterval: foodRequirements!.feedingInterval, lastFeedingTime: lastFeedingTime)
                }
            } else {
                timerManager.startTimer(feedingInterval: foodRequirements!.feedingInterval, lastFeedingTime: nil)
            }
        }
        isLoading = false
    }
    
    private func fetchFeedingRecords() {
        if let records = db.fetchFeedingRecords(petId: petId) {
            let dateFormatter = ISO8601DateFormatter()
            let now = Date()
            let last24Hours = Calendar.current.date(byAdding: .hour, value: -24, to: now)!
            
            // Filter and sort feeding records
            feedingRecords = records.compactMap { record in
                if let date = dateFormatter.date(from: record), date >= last24Hours {
                    return date
                }
                return nil
            }.sorted(by: >) // Sort with latest first
        }
    }
    
    private func formatDate(_ date: Date) -> String {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
    
    private func logFeeding() {
        db.addFeedingRecord(petId: petId)
        fetchFeedingRecords()
        
        // Restart the timer only after logging a feeding
        timerManager.startTimer(feedingInterval: foodRequirements!.feedingInterval, lastFeedingTime: Date())
    }
    
    private func loadPetImage() {
        petImage = loadImageFromJSON(petId: petId)
    }
    
    // Helper function to format date
    private func formatDate(_ dateString: String) -> String? {
        let dateFormatter = ISO8601DateFormatter()
        if let date = dateFormatter.date(from: dateString) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "dd MMM yyyy"
            return outputFormatter.string(from: date)
        }
        return nil
    }
    
    // Helper function to calculate age with months
    private func calculateAgeWithMonths(_ dateString: String) -> String? {
        let dateFormatter = ISO8601DateFormatter()
        if let dob = dateFormatter.date(from: dateString) {
            let calendar = Calendar.current
            let now = Date()
            let ageComponents = calendar.dateComponents([.year, .month], from: dob, to: now)
            if let years = ageComponents.year, let months = ageComponents.month {
                return "\(years) years \(months) months"
            }
        }
        return nil
    }
}

// Helper function to hide keyboard
extension View {
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?
    @Environment(\.presentationMode) private var presentationMode

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            parent.presentationMode.wrappedValue.dismiss()

            if let itemProvider = results.first?.itemProvider, itemProvider.canLoadObject(ofClass: UIImage.self) {
                itemProvider.loadObject(ofClass: UIImage.self) { (image, error) in
                    if let image = image as? UIImage {
                        DispatchQueue.main.async {
                            self.parent.selectedImage = image
                        }
                    }
                }
            }
        }
    }
}

func loadImageFromJSON(petId: Int) -> UIImage? {
    let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("petImage_\(petId).json")
    
    do {
        let jsonData = try Data(contentsOf: fileURL)
        if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
           let imageBase64String = json["image"] as? String,
           let imageData = Data(base64Encoded: imageBase64String) {
            return UIImage(data: imageData)
        }
    } catch {
        print("Error loading image from JSON: \(error)")
    }
    return nil
}

@MainActor
struct PetFoodRequirements {
    var foodAmount: Double
    var foodType: String
    var feedingInterval: TimeInterval
}



func calculateFoodRequirements(for pet: Pet) -> PetFoodRequirements {
    let weight = Double(pet.petWeight) ?? 0.0
    let age = pet.age ?? 0
    
    var foodAmount: Double = 0.0
    var foodType: String = ""
    var feedingInterval: TimeInterval = 0.0
    
    if pet.petType == "Dog" {
        foodType = "Dry Dog Food"
        if age < 1 {
            foodAmount = weight * 0.05 // Puppies need more food
            feedingInterval = 4 * 3600 // Every 4 hours
        } else {
            foodAmount = weight * 0.02 // Adult dogs
            feedingInterval = 8 * 3600 // Every 8 hours
        }
    } else if pet.petType == "Cat" {
        foodType = "Dry Cat Food"
        if age < 1 {
            foodAmount = weight * 0.03 // Kittens need more food
            feedingInterval = 4 * 3600 // Every 4 hours
        } else {
            foodAmount = weight * 0.015 // Adult cats
            feedingInterval = 8 * 3600 // Every 8 hours
        }
    }
    
    return PetFoodRequirements(foodAmount: foodAmount, foodType: foodType, feedingInterval: feedingInterval)
}

import Foundation
import Combine

class TimerManager: ObservableObject {
    @Published var timeRemaining: TimeInterval = 0
    @Published var nextFeedingTime: Date?
    @Published var isTimerEnded: Bool = false // Track if the timer has ended
    
    private var timer: Timer?
    private var feedingInterval: TimeInterval = 0
    
    func startTimer(feedingInterval: TimeInterval, lastFeedingTime: Date?) {
        self.feedingInterval = feedingInterval
        self.isTimerEnded = false // Reset the timer state when starting

        if let lastFeedingTime = lastFeedingTime {
            nextFeedingTime = lastFeedingTime.addingTimeInterval(feedingInterval)
            timeRemaining = max(0, nextFeedingTime!.timeIntervalSince(Date())) // Ensure timeRemaining is not negative
        } else {
            nextFeedingTime = Date().addingTimeInterval(feedingInterval)
            timeRemaining = feedingInterval
        }

        timer?.invalidate() // Stop any existing timer

        // Use `[weak self]` to avoid strong capture of self
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            DispatchQueue.main.async {
                self?.updateTimer()
            }
        }
    }
    
    private func updateTimer() {
        guard let nextFeedingTime = nextFeedingTime else { return }
        
        let currentTime = Date()
        timeRemaining = max(0, nextFeedingTime.timeIntervalSince(currentTime)) // Ensure timeRemaining is not negative
        
        if timeRemaining <= 0 {
            timeRemaining = 0
            isTimerEnded = true // Set the timer state to ended
            stopTimer() // Stop the timer
        }
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    func formattedTime(_ timeInterval: TimeInterval) -> String {
        let hours = Int(timeInterval) / 3600
        let minutes = Int(timeInterval) / 60 % 60
        let seconds = Int(timeInterval) % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
}

class FeedingManager {
    private let db: SQLiteDatabase
    
    init(db: SQLiteDatabase) {
        self.db = db
    }
    
    @MainActor func logFeeding(petId: Int) {
        db.addFeedingRecord(petId: petId)
    }
    
    @MainActor func fetchFeedingRecords(petId: Int) -> [String]? {
        return db.fetchFeedingRecords(petId: petId)
    }
    
    @MainActor func fetchMostRecentFeedingRecord(petId: Int) -> String? {
        return db.fetchMostRecentFeedingRecord(petId: petId)
    }
}
private func petEmoji(for pet: Pet, progress: Double) -> Image? {
    switch pet.petType {
    case "Cat":
        if progress > 0.5 {
            return Image("smilingcat")
        } else if progress > 0 {
            return Image("neutralcat")
        } else {
            return Image("sadcat")
        }
    case "Dog":
        if progress > 0.5 {
            return Image("smilingdog")
        } else if progress > 0 {
            return Image("neutraldog")
        } else {
            return Image("saddog")
        }
    default:
        return nil
    }
}
private func calculateFeedingInterval(for pet: Pet) -> TimeInterval {
    let weight = Double(pet.petWeight) ?? 0.0
    let age = pet.age ?? 0

    if pet.petType == "Dog" {
        if age < 1 {
            return 4 * 3600 // Puppies: every 4 hours
        } else if weight < 10 {
            return 6 * 3600 // Small adult dogs: every 6 hours
        } else if weight < 25 {
            return 8 * 3600 // Medium adult dogs: every 8 hours
        } else {
            return 10 * 3600 // Large adult dogs: every 10 hours
        }
    } else if pet.petType == "Cat" {
        if age < 1 {
            return 4 * 3600 // Kittens: every 4 hours
        } else if weight < 4 {
            return 6 * 3600 // Small adult cats: every 6 hours
        } else {
            return 8 * 3600 // Larger adult cats: every 8 hours
        }
    }

    return 3600 // Default to 1 hour if pet type is unknown
}

// MARK: - Feeding History View
struct FeedingHistoryView: View {
    var feedingRecords: [Date]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Feeding History")
                .font(.title)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            if !feedingRecords.isEmpty {
                
                
                // Detailed List of Feeding Records
                List {
                    ForEach(feedingRecords, id: \.self) { record in
                        HStack {
                            Image(systemName: "clock.fill")
                                .foregroundColor(.blue)
                            Text(formatDate(record))
                                .font(.body)
                            Spacer()
                            Text("\(record, style: .relative) ago")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                        .padding(.vertical, 8)
                    }
                }
                .listStyle(PlainListStyle())
                .frame(height: 400) // Limit the height of the list
            } else {
                Text("No feeding records found.")
                    .foregroundColor(.gray)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(15)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(15)
    }
    
    // Helper function to format date
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
