import SwiftUI
import SQLite3

// MARK: - Main View
struct MainView: View {
    @State private var isFirstLaunch: Bool = !UserDefaults.standard.bool(forKey: "isFirstLaunch")
    
    var body: some View {
        NavigationView {
            ZStack {
                if isFirstLaunch {
                    PetInfoFormView()
                } else {
                    ContentView()
                }
            }
        }
    }
}

// MARK: - SQLite Helper Class
@MainActor
class SQLiteDatabase {
    static let shared = SQLiteDatabase() // Singleton instance
    var db: OpaquePointer?

    private init() {
        let fileURL = try! FileManager.default
            .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("petInfoDatabase.db")

        print("Database file path: \(fileURL.path)")

        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Database opened successfully!")
        }

        createTable()
    }

    private func createTable() {
        let createTableQuery = """
        CREATE TABLE IF NOT EXISTS pets (
            petId INTEGER PRIMARY KEY AUTOINCREMENT,
            petType TEXT,
            petBreed TEXT,
            petWeight TEXT,
            petAge TEXT,
            petGender TEXT
        );
        """

        if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creating table: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Table created successfully.")
        }
    }

    func savePetInfo(petType: String, breed: String, weight: String, age: String, gender: String) {
        print("Inserting: petType=\(petType), breed=\(breed), weight=\(weight), age=\(age), gender=\(gender)")

        let insertQuery = "INSERT INTO pets (petType, petBreed, petWeight, petAge, petGender) VALUES (?, ?, ?, ?, ?);"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing insert query: \(String(cString: sqlite3_errmsg(db)))")
            return
        }

        sqlite3_bind_text(statement, 1, (petType as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 2, (breed as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 3, (weight as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 4, (age as NSString).utf8String, -1, nil)
        sqlite3_bind_text(statement, 5, (gender as NSString).utf8String, -1, nil)

        if sqlite3_step(statement) != SQLITE_DONE {
            print("Error executing insert query: \(String(cString: sqlite3_errmsg(db)))")
        } else {
            print("Pet information saved successfully.")
        }

        sqlite3_finalize(statement)
    }

    func getLastInsertedPetId() -> Int? {
        let query = "SELECT last_insert_rowid()"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing last_insert_rowid query")
            return nil
        }

        if sqlite3_step(statement) == SQLITE_ROW {
            let petId = sqlite3_column_int(statement, 0)
            sqlite3_finalize(statement)
            return Int(petId)
        }

        sqlite3_finalize(statement)
        return nil
    }

    func fetchPetDetails(petId: Int) -> Pet? {
        let query = "SELECT petType, petBreed, petWeight, petAge, petGender FROM pets WHERE petId = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) != SQLITE_OK {
            print("Error preparing fetch query: \(String(cString: sqlite3_errmsg(db)))")
            return nil
        }

        sqlite3_bind_int(statement, 1, Int32(petId))

        if sqlite3_step(statement) == SQLITE_ROW {
            let petType = String(cString: sqlite3_column_text(statement, 0))
            let petBreed = String(cString: sqlite3_column_text(statement, 1))
            let petWeight = String(cString: sqlite3_column_text(statement, 2))
            let petAge = String(cString: sqlite3_column_text(statement, 3))
            let petGender = String(cString: sqlite3_column_text(statement, 4))

            sqlite3_finalize(statement)
            return Pet(id: petId, petType: petType, petBreed: petBreed, petWeight: petWeight, petAge: petAge, petGender: petGender)
        }

        sqlite3_finalize(statement)
        return nil
    }
    @MainActor
    private func closeDatabase() {
            if db != nil {
                sqlite3_close(db)
                db = nil
            }
        }
}
// MARK: - Pet Model
struct Pet {
    var id: Int
    var petType: String
    var petBreed: String
    var petWeight: String
    var petAge: String
    var petGender: String
}

// MARK: - Pet Info Form View
struct PetInfoFormView: View {
    @State private var petType: String = "Dog"
    @State private var breed: String = ""
    @State private var weight: String = ""
    @State private var pname: String = ""
    @State private var age: String = ""
    @State private var gender: String = "Male"
    @State private var petId: Int? = nil
    @State private var showStatisticsPage: Bool = false

    let catBreeds = ["Persian", "Siamese", "Maine Coon", "Ragdoll"]
    let dogBreeds = ["Golden Retriever", "Bulldog", "Poodle", "Beagle"]

    var body: some View {
        ZStack {
            // Background Pawprints
            VStack {
                HStack {
                    Spacer()
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 75, height: 75)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding()
                        .padding(.top, 30)
                    
                }
                Spacer()
            }
            VStack {
                Spacer()
                HStack {
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding().padding(.bottom,90)
                    Spacer()
                }
            }
            VStack(spacing: 25) {
                HStack{
                    Text("Welcome to HealthyPaws!").lineLimit(nil)
                        .font(.system(size: 35, weight: .bold)).multilineTextAlignment(.leading)
                        .frame(height: 90.0)
                    Spacer()
                }
                Picker("What type of pet do you have?", selection: $petType) {
                    Text("Cat 🐱").tag("Cat")
                    Text("Dog 🐶").tag("Dog")
                }.padding()
                    .pickerStyle(SegmentedPickerStyle())
                
                TextField("Enter your Pet's name", text: $pname)
                    .textFieldStyle(RoundedBorderTextFieldStyle()).padding().onTapGesture {
                        hideKeyboard()
                    }
                
                HStack{
                    Text("Select the Breed of your pet")
                        .foregroundColor(Color.gray)
                        .multilineTextAlignment(.leading).lineLimit(nil)
                        .frame(width: 200.0, height: 60.0)
                    
                    Picker("Select Breed", selection: $breed) {
                        ForEach(petType == "Cat" ? catBreeds : dogBreeds, id: \.self) { breed in
                            Text(breed).tag(breed)
                        }
                    }
                    .onAppear {
                        // Set default breed when the view appears
                        breed = petType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                    }
                    .onChange(of: petType) { newType in
                        // Update breed automatically when petType changes
                        breed = newType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                    }
                    .layoutPriority(1)
                    .pickerStyle(MenuPickerStyle())
                }
                TextField("Enter weight (kg)", text: $weight)
                    .textFieldStyle(RoundedBorderTextFieldStyle()).padding()
                
                TextField("Enter age (years)", text: $age)
                    .textFieldStyle(RoundedBorderTextFieldStyle()).padding()
                
                Picker("Select Gender", selection: $gender) {
                    Text("Male").tag("Male")
                    Text("Female").tag("Female")
                }
                .pickerStyle(SegmentedPickerStyle()).padding()
                Spacer()
                
                NavigationStack {
                    VStack {
                        Button(action: savePetInfo) {
                            Text("Save & Continue")
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .disabled(breed.isEmpty || weight.isEmpty || age.isEmpty)
                    }
                    .navigationDestination(isPresented: $showStatisticsPage) {
                        if let petId = petId {
                            PetStatisticsView(petId: petId)
                        }
                    }
                }
            }
            .padding()
            .padding()
        }
    }
    private func savePetInfo() {
        print("Saving Pet Info: Type=\(petType), Breed=\(breed), Weight=\(weight), Age=\(age), Gender=\(gender)")
        SQLiteDatabase.shared.savePetInfo(petType: petType, breed: breed, weight: weight, age: age, gender: gender)
        if let insertedPetId = SQLiteDatabase.shared.getLastInsertedPetId() {
            petId = insertedPetId
            showStatisticsPage = true
        }
    }
    
}
// Helper function to hide keyboard
extension View {
    func hideKeyboard() {
        let resign = #selector(UIResponder.resignFirstResponder)
        UIApplication.shared.sendAction(resign, to: nil, from: nil, for: nil)
    }
}
struct PetStatisticsView: View {
    var petId: Int
    @State private var pet: Pet?
    @State private var isLoading = true
    
    let db = SQLiteDatabase.shared
    
    var body: some View {
        VStack(spacing: 20) {
            if isLoading {
                Text("Loading pet details...")
                    .font(.title)
                    .foregroundColor(.gray)
            } else if let pet = pet {
                Text("Pet Statistics")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Type: \(pet.petType)")
                Text("Weight: \(pet.petWeight) kg")
                Text("Breed: \(pet.petBreed)")
                Text("Age: \(pet.petAge) years")
                Text("Gender: \(pet.petGender)")
            } else {
                Text("No pet details found.")
                    .foregroundColor(.red)
            }
        }
        .padding()
        .onAppear {
            fetchPetDetails()
        }
    }
    
    private func fetchPetDetails() {
        print("Fetching pet details for petId: \(petId)")
        
        if let petDetails = db.fetchPetDetails(petId: petId) {
            pet = petDetails
        }
        isLoading = false // Set loading to false after data is fetched
    }
}
