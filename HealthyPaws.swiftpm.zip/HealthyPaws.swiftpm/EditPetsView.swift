//
//  EditPetsView.swift
//  HealthyPaws
//
//  Created by Siddhesh M on 16/02/25.
//
import SwiftUI



struct EditPetsView: View {
    @State private var pets: [Pet] = []
    @State private var selectedPet: Pet?
    @State private var petImages: [Int: UIImage] = [:] // Store images per pet

    var body: some View {
        NavigationStack {
            ZStack {
                // Background Pawprints
                VStack {
                    HStack {
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 75, height: 75)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding(.leading, 25)
                            .padding(.top, 60)
                        Spacer()
                    }
                    Spacer()
                }
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "pawprint.fill")
                            .resizable()
                            .scaledToFit()
                            .rotationEffect(.degrees(-25))
                            .frame(width: 150, height: 150)
                            .foregroundColor(.gray.opacity(0.2))
                            .padding()
                    }
                }
                List {
                    ForEach(pets, id: \.id) { pet in
                        NavigationLink(destination: EditPetDetailView(pet: pet) { updatedPet in
                            if let index = pets.firstIndex(where: { $0.id == updatedPet.id }) {
                                pets[index] = updatedPet
                            }
                            fetchPets() // Reload the pets list
                        }) {
                            HStack {
                                if let petImage = petImages[pet.id] {
                                    Image(uiImage: petImage)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 120, height: 120)
                                        .clipShape(Circle())
                                } else {
                                    Image(systemName: "photo.circle")
                                        .resizable()
                                        .scaledToFit()
                                        .clipShape(Circle())
                                        .frame(width: 120, height: 120)
                                        .foregroundColor(.gray)
                                        .task {
                                            await loadPetImage(for: pet.id)
                                        }
                                }
                                Text(pet.pname)
                            }
                        }
                        
                    }
                    .onDelete(perform: deletePet)
                }
            }
            .navigationTitle("Edit Pets")
            .toolbar {
                // Reload Button
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        reloadPetsAndImages() // Reload both pets and images
                    }) {
                        Image(systemName: "arrow.clockwise")
                            .foregroundColor(.blue)
                    }
                }
                // Edit Button
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
            }
            .onAppear {
                fetchPets()
            }
        }
    }

    // Function to reload both pets and images
    private func reloadPetsAndImages() {
        fetchPets() // Reload the pets list
        petImages.removeAll() // Clear the image cache
        for pet in pets {
            Task {
                await loadPetImage(for: pet.id) // Reload images for each pet
            }
        }
    }

    // Async function to load pet image
    func loadPetImage(for petId: Int) async {
        if let image = await loadImageFromJSON(petId: petId) {
            await MainActor.run {
                petImages[petId] = image
            }
        }
    }

    // Function to load image from JSON file
    func loadImageFromJSON(petId: Int) async -> UIImage? {
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            .first!.appendingPathComponent("petImage_\(petId).json")

        do {
            let jsonData = try Data(contentsOf: fileURL)
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let imageBase64String = json["image"] as? String,
               let imageData = Data(base64Encoded: imageBase64String) {
                return UIImage(data: imageData)
            }
        } catch {
            print("Error loading image from JSON: \(error)")
        }
        return nil
    }

    private func fetchPets() {
        if let fetchedPets = SQLiteDatabase.shared.fetchAllPets() {
            pets = fetchedPets
        }
    }

    private func deletePet(at offsets: IndexSet) {
        for index in offsets {
            let pet = pets[index]
            SQLiteDatabase.shared.deletePet(petId: pet.id)
            petImages.removeValue(forKey: pet.id) // Remove image from cache
        }
        pets.remove(atOffsets: offsets)
    }
}

struct EditPetDetailView: View {
    @State var pet: Pet
    var onSave: (Pet) -> Void // Callback to notify parent view
    @Environment(\.presentationMode) var presentationMode

    @State private var petType: String = "Dog"
    @State private var breed: String = ""
    @State private var weight: String = ""
    @State private var pname: String = ""
    @State private var dob: Date = Date()
    @State private var gender: String = "Male"
    @State private var selectedImage: UIImage? = nil
    @State private var isImagePickerPresented: Bool = false
    @State private var petImages: [Int: UIImage] = [:]

    let catBreeds = ["Persian", "Siamese", "Maine Coon", "Ragdoll"]
    let dogBreeds = ["Golden Retriever", "Bulldog", "Poodle", "Beagle"]

    var body: some View {
        ZStack {
            // Background Pawprints
            VStack {
                HStack {
                    Spacer()
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 75, height: 75)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding()
                        .padding(.top, 30)
                }
                Spacer()
            }
            VStack {
                Spacer()
                HStack {
                    Image(systemName: "pawprint.fill")
                        .resizable()
                        .scaledToFit()
                        .rotationEffect(.degrees(-25))
                        .frame(width: 150, height: 150)
                        .foregroundColor(.gray.opacity(0.2))
                        .padding().padding(.bottom, 90)
                    Spacer()
                }
            }
            VStack(spacing: 15) {
                HStack {
                    Text("Edit Pet Details").lineLimit(nil)
                        .font(.system(size: 35, weight: .bold)).multilineTextAlignment(.leading)
                        .frame(height: 90.0)
                    Spacer()
                }
                Spacer()
                VStack {
                    if let selectedImage = selectedImage {
                        Image(uiImage: selectedImage)
                            .resizable()
                            .padding(.bottom, 10.0)
                            .scaledToFit()
                            .frame(height: 140).clipShape(Circle())
                    }
                    else if let petImage = petImages[pet.id] {
                        Image(uiImage: petImage)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                    }
                    else{
                        // Placeholder image if no image is available
                        Image(systemName: "photo.circle")
                            .resizable()
                            .foregroundColor(Color.gray)
                            .scaledToFit()
                            .frame(height: 140).clipShape(Circle())
                    }
                    Button(action: {
                        isImagePickerPresented = true
                    }) {
                        HStack {
                            Text("Select Pet Image")
                                .padding()
                            Image(systemName: "photo.badge.plus")
                                .padding()
                        }
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                    }
                    .sheet(isPresented: $isImagePickerPresented) {
                        ImagePicker(selectedImage: $selectedImage)
                    }
                }
                Picker("What type of pet do you have?", selection: $petType) {
                    Text("Cat 🐱").tag("Cat")
                    Text("Dog 🐶").tag("Dog")
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding().padding()
                .frame(height: 60)
                .scaleEffect(1.2)

                TextField("Enter your Pet's name", text: $pname)
                    .textFieldStyle(RoundedBorderTextFieldStyle()).padding(.horizontal, 32.0).onTapGesture {
                        hideKeyboard()
                    }.scaleEffect(1.2)

                HStack {
                    Text("Select the Breed of your pet")
                        .foregroundColor(Color.gray)
                        .multilineTextAlignment(.leading).lineLimit(nil)
                        .frame(width: 200.0, height: 60.0)

                    Picker("Select Breed", selection: $breed) {
                        ForEach(petType == "Cat" ? catBreeds : dogBreeds, id: \.self) { breed in
                            Text(breed).tag(breed)
                        }
                    }
                    .onAppear {
                        breed = petType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                    }
                    .onChange(of: petType) { newType in
                        breed = newType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                    }
                    .layoutPriority(1)
                    .pickerStyle(MenuPickerStyle())
                }
                TextField("Enter weight (kg)", text: $weight).padding(.horizontal, 32.0)
                    .textFieldStyle(RoundedBorderTextFieldStyle()).scaleEffect(1.2)

                DatePicker("Select Date of Birth", selection: $dob, displayedComponents: .date).foregroundColor(Color.gray)
                    .padding()

                Picker("Select Gender", selection: $gender) {
                    Text("Male").tag("Male")
                    Text("Female").tag("Female")
                }
                .pickerStyle(SegmentedPickerStyle()).padding().padding().scaleEffect(1.2).frame(height: 60)

                Button(action: savePetInfo) {
                    Text("Save Changes")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .disabled(breed.isEmpty || weight.isEmpty)
            }
            .padding()
            .padding()
        }
        .onAppear {
            // Pre-fill the form with existing pet details
            petType = pet.petType
            breed = pet.petBreed
            weight = pet.petWeight
            pname = pet.pname
            dob = ISO8601DateFormatter().date(from: pet.petDOB) ?? Date()
            gender = pet.petGender

            // Load the saved image
            Task {
                await loadPetImage(for: pet.id)
            }
        }
    }

    private func savePetInfo() {
        // Update the pet object with the new details
        pet.petType = petType
        pet.petBreed = breed
        pet.petWeight = weight
        pet.pname = pname
        pet.petDOB = ISO8601DateFormatter().string(from: dob)
        pet.petGender = gender

        // Save the updated pet details to the database
        SQLiteDatabase.shared.updatePetInfo(
            petId: pet.id,
            petType: pet.petType,
            breed: pet.petBreed,
            weight: pet.petWeight,
            dob: pet.petDOB,
            gender: pet.petGender,
            pname: pet.pname
        )

        // Save the new image if selected
        if selectedImage != nil {
            saveImageToJSON(petId: pet.id)
        }

        // Notify the parent view to update the list
        onSave(pet)

        // Dismiss the view
        presentationMode.wrappedValue.dismiss()
    }

    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    private func saveImageToJSON(petId: Int) {
        guard let selectedImage = selectedImage else { return }
        
        if let imageData = selectedImage.jpegData(compressionQuality: 1.0) {
            let imageBase64String = imageData.base64EncodedString()
            
            let petImageData = ["petId": petId, "image": imageBase64String] as [String : Any]
            
            if let jsonData = try? JSONSerialization.data(withJSONObject: petImageData, options: .prettyPrinted) {
                let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("petImage_\(petId).json")
                
                do {
                    try jsonData.write(to: fileURL)
                    print("Image saved to JSON file at: \(fileURL.path)")
                } catch {
                    print("Error saving image to JSON: \(error)")
                }
            }
        }
    }

    func loadPetImage(for petId: Int) async {
        if let image = await loadImageFromJSON(petId: petId) {
            await MainActor.run {
                petImages[petId] = image
            }
        }
    }

    func loadImageFromJSON(petId: Int) async -> UIImage? {
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            .first!.appendingPathComponent("petImage_\(petId).json")

        do {
            let jsonData = try Data(contentsOf: fileURL)
            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
               let imageBase64String = json["image"] as? String,
               let imageData = Data(base64Encoded: imageBase64String) {
                return UIImage(data: imageData)
            }
        } catch {
            print("Error loading image from JSON: \(error)")
        }
        return nil
    }
}
