import SwiftUI

struct EmergencyView: View {
    let helplines: [(name: String, phone: String, website: String)] = [
        ("Blue Cross of India", "+91 44 4627 4999", "https://bluecrossofindia.org"),
        ("PETA India", "+91 98201 22602", "https://www.petaindia.com"),
        ("Animal Welfare Board of India", "0129-2555700", "https://awbi.gov.in"),
        ("People for Animals", "", "https://www.peopleforanimalsindia.org"),
        ("Sanjay Gandhi Animal Care Centre", "+91 95608 02425", "https://sanjaygandhianimalcarecentre.org"),
        ("World For All", "", "https://www.worldforall.co")
    ]
    
    var body: some View {
        NavigationView {
            List {
                ForEach(helplines, id: \.name) { helpline in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(helpline.name)
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        if !helpline.phone.isEmpty {
                            Link("📞 \(helpline.phone)", destination: URL(string: "tel:\(helpline.phone)")!)
                                .foregroundColor(.blue)
                        }
                        
                        Link("🌐 Website", destination: URL(string: helpline.website)!)
                            .foregroundColor(.blue)
                    }
                    .padding(.vertical, 5)
                }
            }
            .navigationTitle("Emergency Helplines")
        }
    }
}

