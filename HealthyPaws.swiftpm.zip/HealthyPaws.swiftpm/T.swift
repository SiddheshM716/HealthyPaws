////
////  T.swift
////  HealthyPaws
////
////  Created by Siddhesh M on 12/02/25.
////
//import SwiftUI
//struct TestView: View {
//    var body: some View {
//        NavigationStack {
//            VStack {
//                NavigationLink {
//                    Text("HALLO!")
//                } label: {
//                    Text("Hello, world!")
//                }
//            }
//            .toolbar {
//                HomeToolbar()
//            }
//            .toolbarTitleMenu { // ADD THIS!
//                Button("Save") {
//                    print("save document")
//                }.buttonStyle(.borderedProminent)
//                
//                Button("Delete") {
//                    print("delete document")
//                }.buttonStyle(.borderedProminent)
//
//                Image(systemName: "bus")
//            }
//            .toolbarColorScheme(.light, for: .navigationBar)
//            .navigationBarTitleDisplayMode(.inline)
//            .navigationTitle("Home")
//            .padding()
//        }
//    }
//}
