//
//  PetInfoFormView.swift
//  HealthyPaws
//
//  Created by Siddhesh M on 16/02/25.
//
import SwiftUI
import SQLite3
import PhotosUI


// MARK: - Pet Info Form View
@MainActor
struct PetInfoFormView: View {
    @State private var petType: String = "Dog"
    @State private var breed: String = ""
    @State private var weight: String = ""
    @State private var pname: String = ""
    @State private var dob: Date = Date()
    @State private var gender: String = "Male"
    @State private var petId: Int? = nil
    @State private var showStatisticsPage: Bool = false
    @State private var selectedImage: UIImage? = nil
    @State private var isImagePickerPresented: Bool = false

    let catBreeds = ["Persian", "Siamese", "Maine Coon", "Ragdoll"]
    let dogBreeds = ["Golden Retriever", "Bulldog", "Poodle", "Beagle"]

    var body: some View {
        Spacer()
        NavigationStack {
            ScrollView{
                
                ZStack {
                    
                    // Background Pawprints
                    VStack {
                        
                        HStack {
                            Spacer()
                            Image(systemName: "pawprint.fill")
                                .resizable()
                                .scaledToFit()
                                .rotationEffect(.degrees(-25))
                                .frame(width: 75, height: 75)
                                .foregroundColor(.gray.opacity(0.2))
                                .padding()
                                .padding(.top, 30)
                        }
                        Spacer()
                    }
                    VStack {
                        Spacer()
                        HStack {
                            Image(systemName: "pawprint.fill")
                                .resizable()
                                .scaledToFit()
                                .rotationEffect(.degrees(-25))
                                .frame(width: 150, height: 150)
                                .foregroundColor(.gray.opacity(0.2))
                                .padding().padding(.bottom, 90)
                            Spacer()
                        }
                    }
                    Spacer()
                    VStack(spacing: 15) {
                        
                        HStack {
                            Text("Welcome to HealthyPaws!").lineLimit(nil)
                                .font(.system(size: 35, weight: .bold)).multilineTextAlignment(.leading)
                                .frame(height: 90.0)
                            Spacer()
                        }
                        
                        
                        VStack{
                            
                            Button(action: {
                                isImagePickerPresented = true
                            }) {
                                if let selectedImage = selectedImage {
                                    ZStack{
                                        Image(uiImage: selectedImage)
                                            .resizable()
                                            .padding(.bottom, 10.0)
                                            .scaledToFit()
                                            .frame(height: 140).clipShape(Circle())
                                        VStack{
                                            Spacer()
                                            HStack{
                                                Spacer()
                                                Image(systemName:"pencil.circle").resizable().scaledToFit().frame(height:30)
                                            }
                                        }
                                    }.frame(width:140,height:140)
                                }
                                else {
                                    // Placeholder image if no image is available
                                    Image(systemName: "photo.badge.plus")
                                        .resizable()
                                        .foregroundColor(Color.gray)
                                        .scaledToFit()
                                        .frame(height: 140).padding(.leading,25)
                                }
                            }
                            .sheet(isPresented: $isImagePickerPresented) {
                                ImagePicker(selectedImage: $selectedImage)
                            }
                            
                            
                        }.padding(.top,10)
                        
                        Picker("What type of pet do you have?", selection: $petType) {
                            Text("Cat 🐱").tag("Cat")
                            Text("Dog 🐶").tag("Dog")
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding().padding()
                        .frame(height: 60)
                        .scaleEffect(1.2)
                        
                        TextField("Enter your Pet's name", text: $pname)
                            .textFieldStyle(RoundedBorderTextFieldStyle()).padding(.horizontal, 32.0).onTapGesture {
                                hideKeyboard()
                            }.scaleEffect(1.2)
                        
                        HStack {
                            Text("Select the Breed of your pet")
                                .foregroundColor(Color.gray)
                                .multilineTextAlignment(.leading).lineLimit(nil)
                                .frame(width: 200.0, height: 60.0)
                            
                            Picker("Select Breed", selection: $breed) {
                                ForEach(petType == "Cat" ? catBreeds : dogBreeds, id: \.self) { breed in
                                    Text(breed).tag(breed)
                                }
                            }
                            .onAppear {
                                breed = petType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                            }
                            .onChange(of: petType) { newType in
                                breed = newType == "Cat" ? catBreeds.first ?? "" : dogBreeds.first ?? ""
                            }
                            .layoutPriority(1)
                            .pickerStyle(MenuPickerStyle())
                        }
                        TextField("Enter weight (kg)", text: $weight).padding(.horizontal, 32.0)
                            .textFieldStyle(RoundedBorderTextFieldStyle()).scaleEffect(1.2)
                        
                        DatePicker("Select Date of Birth", selection: $dob, displayedComponents: .date).foregroundColor(Color.gray)
                            .padding()
                        
                        Picker("Select Gender", selection: $gender) {
                            Text("Male").tag("Male")
                            Text("Female").tag("Female")
                        }
                        .pickerStyle(SegmentedPickerStyle()).padding().padding().scaleEffect(1.2).frame(height: 60)
                        
                        VStack {
                            Button(action: savePetInfo) {
                                Text("Save & Continue")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.blue)
                                    .foregroundColor(.white)
                                    .cornerRadius(15)
                            }
                            .disabled(breed.isEmpty || weight.isEmpty)
                        }
                        .navigationDestination(isPresented: $showStatisticsPage) {
                            if let petId = petId {
                                PetStatisticsView(petId: petId)
                            }
                        }
                        
                    }
                    
                    .padding()
                    .padding()
                }.padding(.top,-20)
            }.ignoresSafeArea()
        }
    }
    private func savePetInfo() {
        let dateFormatter = ISO8601DateFormatter()
        let dobString = dateFormatter.string(from: dob)
        
        print("Saving Pet Info: Type=\(petType), Breed=\(breed), Weight=\(weight), DOB=\(dobString), Gender=\(gender), Name=\(pname)")
        SQLiteDatabase.shared.savePetInfo(petType: petType, breed: breed, weight: weight, dob: dobString, gender: gender, pname: pname)
        if let insertedPetId = SQLiteDatabase.shared.getLastInsertedPetId() {
            petId = insertedPetId
            saveImageToJSON(petId: insertedPetId)
            showStatisticsPage = true
        }
    }

    private func saveImageToJSON(petId: Int) {
        guard let selectedImage = selectedImage else { return }
        
        if let imageData = selectedImage.jpegData(compressionQuality: 1.0) {
            let imageBase64String = imageData.base64EncodedString()
            
            let petImageData = ["petId": petId, "image": imageBase64String] as [String : Any]
            
            if let jsonData = try? JSONSerialization.data(withJSONObject: petImageData, options: .prettyPrinted) {
                let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("petImage_\(petId).json")
                
                do {
                    try jsonData.write(to: fileURL)
                    print("Image saved to JSON file at: \(fileURL.path)")
                } catch {
                    print("Error saving image to JSON: \(error)")
                }
            }
        }
    }
}
